﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinkPayment.Model
{
    public class PaymentEntity
    {
        public string version { get; set; }//版本号
        public string input_charset { get; set; } //参数字符集编码 
        public string merchant_code { get; set; }//商户号
        public string amount { get; set; } //金额
        public string order_no { get; set; } //订单号
        public long batch_no { get; set; }//批次号
        public string request_time { get; set; } //代付时间yyyy-MM-dd HH:mm:ss
        public string bank_code { get; set; }//银行编码
        public string account_name { get; set; }//收款人名称
        public string account_number { get; set; }//收款卡号
        public string remark { get; set; }//备注
        public string notify_url { get; set; }//推送下发失败状态结果
    }

    //订单查询
    public class PaymentOrder
    {
        public string version { get; set; }//版本号
        public string input_charset { get; set; } //参数字符集编码 
        public string merchant_code { get; set; }//商户号
        public string order_no { get; set; } //订单号
        public string request_time { get; set; } //查询时间yyyy-MM-dd HH:mm:ss
    }

    //余额查询
    public class PaymentBanlance
    {
        public string version { get; set; }//版本号
        public string input_charset { get; set; } //参数字符集编码 
        public string merchant_code { get; set; }//商户号
        public string request_time { get; set; } //查询时间
        public string order_no { get; set; } //订单号
    }

}

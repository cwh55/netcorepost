﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinkPayment.Model
{
    public class LogRecord
    {
        public long LogId { get; set; }
        public string Ip { get; set; }
        public sbyte LogLevel { get; set; }
        public int LogType { get; set; }
        public string CreateName { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public long OrderNo { get; set; }
        public string LogRemark { get; set; }
        public int? CompanyId { get; set; }
        public Company UCompany { get; set; }
        public string RequestUrl { get; set; }
        public string RequestData { get; set; }
        public string AffectData { get; set; }
    }

    /// <summary>
    /// 日志类型枚举
    /// </summary>
    public enum LogLevel
    {
        Success = 1,
        Failure = 2,
        Error = 3
    }

    /// <summary>
    /// 日志类型枚举
    /// </summary>
    public enum LogRecordLogType
    {
        UpdateBalance = 1381,//修改各公司余额
        Less = 1391,//付款后的余额
        UpdatePaymentRecord = 1380,//修改订单
        UpdatePayFee = 1390,//修改费率
    }

}

﻿using System;
using System.Collections.Generic;
using System.Text;
using LinkPayment.Model;

namespace LinkPayment
{
    public class SysConfig
    {
        public int ConfigId { get; set; }
        public string ConfigCode { get; set; }
        public int ConfigValue { get; set; }
        public string ConfigContent { get; set; }
        public int CompanyId { get; set; }
        public string Description { get; set; }
        public Company Company { get; set; }
    }
}

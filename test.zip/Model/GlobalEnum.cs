﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinkPayment.Model
{
    public class GlobalEnum
    {
        public enum OrderStatus
        {
           未处理=0,
           银行处理中=1,
           已打款=2,
           失败=3
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinkPayment.Model
{
    public class BankCard
    {
        public int Bcid { get; set; }
        public long OrderNo { get; set; }
        public string BankCode { get; set; }
        public string BankName { get; set; }
        public string CardNumber { get; set; }
        public string SecCardNumber { get; set; }
        public string CardName { get; set; }
        public sbyte CardType { get; set; }
        public sbyte PaymentType { get; set; }
        public decimal? Balance { get; set; }
        public DateTime? BalanceLastUpdate { get; set; }
        public sbyte UsingStatus { get; set; }
        public sbyte EnableStatus { get; set; }
        public string LoginName { get; set; }
        public string PasswordLogin { get; set; }
        public string PasswordQuery { get; set; }
        public string PasswordPay { get; set; }
        public string PasswordShield { get; set; }
        public sbyte UsbType { get; set; }
        public string UsbSerialNumber { get; set; }
        public string OriginalPassword { get; set; }
        public string AccountBank { get; set; }
        public string DocumentNumber { get; set; }
        public string PhoneNumber { get; set; }
        public decimal PaymentStart { get; set; }
        public decimal PaymentEnd { get; set; }
        public decimal PayFeeRatio { get; set; }
        public decimal DepositFeeRatio { get; set; }
        public decimal TransportRate { get; set; }
        public sbyte CrossBankPay { get; set; }
        public string DepositType { get; set; }
        public string BankPhoto { get; set; }
        public int CompanyId { get; set; }
        public string Remark { get; set; }
        public int CreateUid { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }
        public string IpAddress { get; set; }
        public string VmClientId { get; set; }
        public DateTime? VmClientIdUpdateDate { get; set; }
        public long? AdjustBalanceRid { get; set; }
    }
}

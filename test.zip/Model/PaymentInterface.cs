﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinkPayment.Model
{
    public class PaymentInterface
    {
        public int PaymentInterfaceID { get; set; } //增加参数

        public int CompanyId { get; set; }
        public sbyte PaymentType { get; set; }
        public string CompanyName { get; set; }
        public string SecretKey { get; set; }
        public decimal PaymentStart { get; set; }
        public decimal PaymentEnd { get; set; }
        public string WithdrawalBank { get; set; }
        public string DepositType { get; set; }
        public int PaymentMax { get; set; }
        public DateTime? LimitCloseDate { get; set; }
        public DateTime? LimitOpenDate { get; set; }
        public sbyte? LimitRepeat { get; set; }
        public sbyte LimitStatus { get; set; }
        public sbyte EnableBalanceCheck { get; set; } //增加参数
        public decimal Balance { get; set; }//增加参数
    }
}

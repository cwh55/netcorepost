﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;
using LinkPayment.Model;

namespace LinkPayment
{
    public class FlashPayContext : DbContext
    {
        private string _month = DateTime.Now.ToString("MM");
        private string _mydb = new ConfigurationBuilder().AddJsonFile("AppSetting.json").Build()["ConnectionStrings:FlashPay"];

        public FlashPayContext()
        {
        }

        public FlashPayContext(DbContextOptions<FlashPayContext> options)
            : base(options)
        {

        }

        public virtual DbSet<SysConfig> SysConfig { get; set; }
        public virtual DbSet<PaymentInterface> PaymentInterface { get; set; }
        public virtual DbSet<PaymentRecord> PaymentRecord { get; set; }

        public virtual DbSet<LogRecord> LogRecord { get; set; }
        public virtual DbSet<Company> Company { get; set; }
        public virtual DbSet<BankCard> BankCard { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PaymentInterface>(entity =>
            {
                entity.HasKey(e => new { e.PaymentInterfaceID });
                entity.Property(e => e.PaymentInterfaceID)
                    .HasColumnName("PaymentInterfaceID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyName).HasColumnType("varchar(500)");

                entity.Property(e => e.DepositType)
                    .IsRequired()
                    .HasDefaultValueSql("''");

                entity.Property(e => e.LimitCloseDate).HasColumnType("datetime");

                entity.Property(e => e.LimitOpenDate).HasColumnType("datetime");

                entity.Property(e => e.LimitRepeat)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.LimitStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.PaymentEnd)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentMax)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PaymentStart)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentType).HasColumnType("tinyint(4)");

                entity.Property(e => e.SecretKey).HasColumnType("text");

                entity.Property(e => e.WithdrawalBank).HasColumnType("varchar(500)");

                entity.Property(e => e.EnableBalanceCheck)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'2'");

                entity.Property(e => e.Balance)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");
            });

            modelBuilder.Entity<SysConfig>(entity =>
            {
                entity.HasKey(e => e.ConfigId);

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => new { e.ConfigCode, e.ConfigValue, e.CompanyId })
                    .HasName("ix_ConfigCode_ConfigValue_CompanyID")
                    .IsUnique();

                entity.Property(e => e.ConfigId)
                    .HasColumnName("ConfigID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ConfigCode)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.ConfigContent).HasColumnType("text");

                entity.Property(e => e.ConfigValue).HasColumnType("int(11)");

                entity.Property(e => e.Description).HasColumnType("text");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.SysConfig)
                    .HasForeignKey(d => d.CompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SysConfig_CompanyID");
            });

            modelBuilder.Entity<PaymentRecord>(entity =>
            {
                entity.HasKey(e => e.OrderNo);

                entity.ToTable("PaymentRecord_" + _month);

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.HasIndex(e => e.PaymentCardId)
                    .HasName("ix_PaymentCardID");

                entity.HasIndex(e => e.PaymentDate)
                    .HasName("ix_PaymentDate");

                entity.HasIndex(e => new { e.CompanyId, e.WithdrawalOrderNo })
                    .HasName("ix_CompanyID_WithdrawalOrderNo")
                    .IsUnique();

                entity.Property(e => e.OrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.AfterBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankSerialNo).HasColumnType("varchar(50)");

                entity.Property(e => e.BeforeBalance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.CardNumber).HasColumnType("varchar(30)");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.ConfirmDate).HasColumnType("datetime");

                entity.Property(e => e.ConfirmName).HasColumnType("varchar(128)");

                entity.Property(e => e.ConfirmStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ConfirmUid)
                    .HasColumnName("ConfirmUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");//新增

                entity.Property(e => e.CreateDbdate)
                    .HasColumnName("CreateDBDate")
                    .HasDefaultValueSql("'current_timestamp(6)'");

                entity.Property(e => e.DepositType).HasColumnType("char(1)");

                entity.Property(e => e.FeeRatio).HasColumnType("decimal(12,8)");

                entity.Property(e => e.FeeTotal).HasColumnType("decimal(16,4)");

                entity.Property(e => e.NoticeLastDate).HasColumnType("datetime");

                entity.Property(e => e.NoticeStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.NoticeTimes)
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PaymentCardId)
                    .HasColumnName("PaymentCardID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.PaymentDate).HasColumnType("datetime");

                entity.Property(e => e.PaymentFailInfo).HasColumnType("text");

                entity.Property(e => e.PaymentRemark).HasColumnType("text");

                entity.Property(e => e.PaymentStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.PaymentType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.ReadDate).HasColumnType("datetime");

                entity.Property(e => e.RecordRealOrderNo).HasColumnType("bigint(20)");

                entity.Property(e => e.WithdrawalAccountName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.WithdrawalAmount).HasColumnType("decimal(16,4) unsigned");

                entity.Property(e => e.WithdrawalFee).HasColumnType("decimal(16,4) unsigned");//新增

                entity.Property(e => e.WithdrawalBankAddress).HasColumnType("varchar(1024)");

                entity.Property(e => e.WithdrawalBankName)
                    .IsRequired()
                    .HasColumnType("varchar(150)");

                entity.Property(e => e.WithdrawalCardBankFlag)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.WithdrawalCardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(64)");

                entity.Property(e => e.WithdrawalOrderNo)
                    .IsRequired()
                    .HasColumnType("varchar(128)");
            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyAddress).HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyBossName).HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyNameEn)
                    .HasColumnName("CompanyNameEN")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CompanyPid)
                    .HasColumnName("CompanyPID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompanyStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.CompanyTel).HasColumnType("varchar(50)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.DepositRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.TransportRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.PayRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UpdateUid)
                    .HasColumnName("UpdateUID")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<LogRecord>(entity =>
            {
                entity.HasKey(e => e.LogId);

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => e.CreateDate)
                    .HasName("ix_CreateDate");

                entity.Property(e => e.LogId)
                    .HasColumnName("LogID")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.AffectData).HasColumnType("longtext");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.OrderNo)
                    .HasColumnType("bigint(20)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.Ip)
                    .HasColumnName("IP")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.LogLevel).HasColumnType("tinyint(4)");

                entity.Property(e => e.LogRemark).HasColumnType("text");

                entity.Property(e => e.LogType).HasColumnType("int(11)");

                entity.Property(e => e.RequestData).HasColumnType("text");

                entity.Property(e => e.RequestUrl)
                    .IsRequired()
                    .HasColumnType("text");
            });

            modelBuilder.Entity<BankCard>(entity =>
            {
                entity.HasKey(e => e.Bcid);

                entity.HasIndex(e => e.CardNumber)
                    .HasName("ix_CardNumber")
                    .IsUnique();

                entity.HasIndex(e => e.CompanyId)
                    .HasName("ix_CompanyID");

                entity.HasIndex(e => e.CreateUid)
                    .HasName("ix_CreateUID");

                entity.HasIndex(e => e.OrderNo)
                    .HasName("ix_OrderNo");

                entity.Property(e => e.Bcid)
                    .HasColumnName("BCID")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AccountBank)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.AdjustBalanceRid)
                    .HasColumnName("AdjustBalanceRID")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.Balance).HasColumnType("decimal(16,4)");

                entity.Property(e => e.BankCode)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.BankName)
                    .IsRequired()
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.CardName)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.CardType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'4'");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CreateDate).HasColumnType("datetime");

                entity.Property(e => e.CreateUid)
                    .HasColumnName("CreateUID")
                    .HasColumnType("int(11)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.CrossBankPay)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'3'");

                entity.Property(e => e.DepositType)
                    .IsRequired()
                    .HasDefaultValueSql("''");

                entity.Property(e => e.DepositFeeRatio)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.DocumentNumber)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.EnableStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'4'");

                entity.Property(e => e.IpAddress).HasColumnType("varchar(50)");

                entity.Property(e => e.LoginName)
                    .IsRequired()
                    .HasColumnType("varchar(128)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.OrderNo)
                    .HasColumnType("bigint(20)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.OriginalPassword)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.PasswordLogin)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.PasswordPay).HasColumnType("varchar(50)");

                entity.Property(e => e.PasswordQuery).HasColumnType("varchar(50)");

                entity.Property(e => e.PasswordShield).HasColumnType("varchar(50)");

                entity.Property(e => e.PayFeeRatio)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.PaymentEnd)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentStart)
                    .HasColumnType("decimal(16,4)")
                    .HasDefaultValueSql("'0.0000'");

                entity.Property(e => e.PaymentType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasColumnType("varchar(50)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.Remark).HasColumnType("text");

                entity.Property(e => e.SecCardNumber)
                    .IsRequired()
                    .HasColumnType("varchar(100)")
                    .HasDefaultValueSql("''");

                entity.Property(e => e.TransportRate)
                    .HasColumnType("decimal(12,8) unsigned")
                    .HasDefaultValueSql("'0.00000000'");

                entity.Property(e => e.UpdateDate).HasColumnType("datetime");

                entity.Property(e => e.UsbType)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'0'");

                entity.Property(e => e.UsingStatus)
                    .HasColumnType("tinyint(4)")
                    .HasDefaultValueSql("'1'");

                entity.Property(e => e.VmClientId).HasColumnType("char(32)");

                entity.Property(e => e.VmClientIdUpdateDate).HasColumnType("datetime");
            });
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(_mydb);
        }

    }
}

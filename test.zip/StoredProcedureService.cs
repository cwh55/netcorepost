﻿using System;
using System.Collections.Generic;
using System.Text;
using LinkPayment.Model;

namespace LinkPayment
{
   public interface StoredProcedureService
    {
        //获取付款记录
        List<PaymentRecord> SelectPaymentRecordNew(DateTime startTime, DateTime endTime,int paymentType, int paymentStatus = 1);

        //获取第三方接口信息
        PaymentInterface GetPaymentInfo(PaymentInterface info);

        //获取配置类型列表
        List<SysConfig> GetTransTypeList(string configCode);


        //修改付款状态等信息
        int UpdatePaymentRecord(PaymentRecord record);

        //修改第三方接口余额
        string UpdatePaymentInterfaceBalance(PaymentRecord record, PaymentInterface payment);

        //修改各公司第三方接口余额
        int UpdatePaymentInterfaceBalance(long orderNo, PaymentInterface payment);

        //修改费用、馀额、出款卡卡号
        int UpdatePaymentBankCard(PaymentRecord record);

        //写日志
        void AddLog(LogRecord record);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using MySql.Data.MySqlClient;
using System.Linq;
using LinkPayment;
using LinkPayment.Model;
using LinkPayment.Common;
using Newtonsoft.Json;

namespace LinkPayment
{
    public class StoredProcedure : StoredProcedureService
    {
        // 获取付款记录(新)
        public List<PaymentRecord> SelectPaymentRecordNew(DateTime startTime, DateTime endTime, int paymentType, int paymentStatus = 1)
        {
            const string command = "CALL sp_SelectPaymentRecordByCreateDate(@startTime, @endTime, @paymentType, @paymentStatus);";

            var pStartTime = new MySqlParameter("startTime", startTime);
            var pEndTime = new MySqlParameter("endTime", endTime);
            var pPaymentType = new MySqlParameter("paymentType", (sbyte)paymentType);
            var pPaymentStatus = new MySqlParameter("paymentStatus", (sbyte)paymentStatus);

            using (var db = new FlashPayContext())
            {
                return db.PaymentRecord.FromSql($"{command}", pStartTime, pEndTime, pPaymentType, pPaymentStatus).ToList();
            }
        }

        //获取第三方接口信息
        public PaymentInterface GetPaymentInfo(PaymentInterface info)
        {
            using (var db = new FlashPayContext())
            {
                return db.PaymentInterface.Where(e => e.PaymentType == info.PaymentType && e.CompanyId == info.CompanyId).FirstOrDefault();
            }
        }

        //获取配置类型列表(暂时没用到)
        public List<SysConfig> GetTransTypeList(string configCode)
        {
            using (var db = new FlashPayContext())
            {
                var q = db.SysConfig.Where(e => e.CompanyId == 2
            && e.ConfigValue == 2
            && e.ConfigCode == configCode).ToList();

                return q;
            }
        }

        private string PaymentTypeName = "(LinkPay)";
        private int PaymentType = 10;
        private decimal PaymentFee = 2; //手续费
        private string RequestUrl = "https://atm.xlinkpay.com/gateway/df_query.html";

        //修改付款状态等信息
        public int UpdatePaymentRecord(PaymentRecord record)
        {
            int rows = 0;
            try
            {
                using (var db = new FlashPayContext())
                {
                    //var paymentRecord = db.PaymentRecord.Where(e => e.OrderNo == record.OrderNo).FirstOrDefault();
                    var paymentRecord = db.PaymentRecord.Where(e => e.WithdrawalOrderNo == record.WithdrawalOrderNo && e.CompanyId == record.CompanyId).FirstOrDefault();

                    #region 处理上个月的订单还没处理完的问题
                    bool isPrev = false;
                    var month = DateTime.Now.AddMonths(-1).ToString("MM");
                    var tableName = $"PaymentRecord_{month}";
                    if (paymentRecord == null)
                    {
                        //var sql = $"SELECT * FROM {tableName} WHERE OrderNo={record.OrderNo}";
                        var sql = $"SELECT * FROM {tableName} WHERE WithdrawalOrderNo='{record.WithdrawalOrderNo}' && CompanyId={record.CompanyId}";
                        paymentRecord = db.PaymentRecord.FromSql(sql).AsNoTracking().SingleOrDefault();
                        isPrev = true;
                    }
                    #endregion

                    if (paymentRecord != null)
                    {
                        paymentRecord.PaymentStatus = record.PaymentStatus;
                        paymentRecord.PaymentDate = DateTime.Now;
                        paymentRecord.ReadDate = null;
                        paymentRecord.PaymentFailInfo = record.PaymentFailInfo;
                        paymentRecord.BankSerialNo = record.BankSerialNo;//修改流水号

                        var sql = "update " + tableName + " set PaymentStatus=" + record.PaymentStatus + ",BankSerialNo='"+record.BankSerialNo+"',PaymentDate='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "',PaymentFailInfo='" + record.PaymentFailInfo + "' where WithdrawalOrderNo='" + paymentRecord.WithdrawalOrderNo + "' && CompanyId='" + paymentRecord.CompanyId + "'";

                        if (paymentRecord.PaymentStatus == 2) //只有付款状态为成功才修改下面这些字段
                        {
                            paymentRecord.NoticeStatus = 1;
                            paymentRecord.NoticeTimes = 0;
                            paymentRecord.RecordRealOrderNo = null;
                            paymentRecord.NoticeLastDate = null;
                            paymentRecord.PaymentFailInfo = null;
                            paymentRecord.WithdrawalFee = PaymentFee;                                                                                      

                            sql = "update " + tableName + " set PaymentStatus=" + record.PaymentStatus + ",BankSerialNo='" + record.BankSerialNo + "',PaymentDate='" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "',ReadDate=null," +
                                "PaymentFailInfo=null,NoticeStatus=1,NoticeTimes=0,RecordRealOrderNo=null,NoticeLastDate=null," +                    
                                $"WithdrawalFee={PaymentFee} where WithdrawalOrderNo='{paymentRecord.WithdrawalOrderNo}' && CompanyId={record.CompanyId}";
                        }

                        if (isPrev)
                        {
                            rows = db.Database.ExecuteSqlCommand(sql);
                        }
                        else
                        {
                            rows = db.SaveChanges();
                        }
                    }
                    else
                    {
                        StringHelper.WriteLog("修改付款订单失败:订单记录不存在");
                    }

                    if (rows > 0)
                    {
                        InsertLog(record.OrderNo.ToString(), "修改付款订单成功" + PaymentTypeName, paymentRecord, LogRecordLogType.UpdatePaymentRecord.GetHashCode(),
                            (sbyte)LogLevel.Success.GetHashCode(), JsonConvert.SerializeObject(record));
                    }
                    else
                    {
                        InsertLog(record.OrderNo.ToString(), "修改付款订单失败" + PaymentTypeName, paymentRecord, LogRecordLogType.UpdatePaymentRecord.GetHashCode(),
                            (sbyte)LogLevel.Error.GetHashCode(), JsonConvert.SerializeObject(record));
                    }
                }
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog("修改付款相关信息时出错:" + ex.ToString());
            }

            return rows;
        }

        //修改付款记录、修改余额
        public string UpdatePaymentInterfaceBalance(PaymentRecord record, PaymentInterface paymentInfo)
        {
            using (var db = new FlashPayContext())
            {
                using (var tran = db.Database.BeginTransaction())//打开事务
                {
                    try
                    {
                        if (record.PaymentStatus == 2) //只有付款状态为成功才修改余额
                        {
                            var pInter = db.PaymentInterface.Where(e => e.PaymentInterfaceID == paymentInfo.PaymentInterfaceID);
                            var payment = pInter.FirstOrDefault();
                            if (payment == null)
                            {
                                InsertLog(paymentInfo.PaymentInterfaceID.ToString(), "第三方接口记录不存在", null,
                                   LogRecordLogType.UpdatePaymentRecord.GetHashCode(), (sbyte)LogLevel.Error.GetHashCode());
                                return "第三方接口记录不存在";
                            }
                            if (payment.Balance <= 0)
                            {
                                InsertLog(paymentInfo.PaymentInterfaceID.ToString(), "余额不足", null,
                                   LogRecordLogType.UpdatePaymentRecord.GetHashCode(), (sbyte)LogLevel.Error.GetHashCode(), JsonConvert.SerializeObject(payment));
                                return "余额不足";
                            }

                            var newBalance = payment.Balance - paymentInfo.Balance;

                            //乐观锁
                            var rows = pInter.Where(e => e.Balance == payment.Balance).FirstOrDefault();

                            if (rows != null && newBalance >= 0)
                            {
                                InsertLog(paymentInfo.PaymentInterfaceID.ToString(), "订单号:" + record.OrderNo + ",当前余额: " + payment.Balance + ",减少余额:" + paymentInfo.Balance.ToString("#0.00") + "(含手续费2元)",
                                    paymentInfo, LogRecordLogType.Less.GetHashCode(), (sbyte)LogLevel.Success.GetHashCode(), JsonConvert.SerializeObject(payment));

                                rows.Balance = newBalance;

                                if (db.SaveChanges() >= 0)
                                {
                                    tran.Commit();
                                }

                                UpdatePaymentRecord(record);

                                InsertLog(paymentInfo.PaymentInterfaceID.ToString(), "订单号:" + record.OrderNo + ",当前余额: " + newBalance,
                                    record, LogRecordLogType.Less.GetHashCode(), (sbyte)LogLevel.Success.GetHashCode(), JsonConvert.SerializeObject(payment));
                                
                                //更新费率
                                UpdatePaymentBankCard(
                                              new PaymentRecord
                                              {
                                                  OrderNo = record.OrderNo,
                                                  WithdrawalOrderNo = record.WithdrawalOrderNo,
                                                  CompanyId = record.CompanyId//改用这两个条件修改订单信息
                                              });

                                return "修改第三方余额成功";
                            }
                            else
                            {
                                InsertLog(paymentInfo.PaymentInterfaceID.ToString(), "订单号:" + record.OrderNo + ",修改第三方余额" + PaymentTypeName + "不成功",
                                    paymentInfo, LogRecordLogType.Less.GetHashCode(), (sbyte)LogLevel.Error.GetHashCode(), JsonConvert.SerializeObject(payment));

                                return "修改第三方余额" + PaymentTypeName + "不成功";
                            }
                        }
                        else
                        {
                            UpdatePaymentRecord(record);
                            return "开始根据返回结果修改付款单信息...";
                        }

                    }
                    catch (Exception ex)
                    {
                        StringHelper.WriteLog("修改第三方余额时" + PaymentTypeName + "出错:" + ex.ToString());
                        InsertLog(paymentInfo.PaymentInterfaceID.ToString(), "修改第三方余额时出错", null,
                           LogRecordLogType.Less.GetHashCode(), (sbyte)LogLevel.Error.GetHashCode());

                        tran.Rollback();
                        tran.Dispose();
                        return "修改第三方余额时" + PaymentTypeName + "出错";
                    }

                }
            }

        }

        //直接修改第三方接口余额
        public int UpdatePaymentInterfaceBalance(long OrderNo, PaymentInterface paymentInfo)
        {
            int rows = 0;
            try
            {
                using (var db = new FlashPayContext())
                {
                    var q = from p in db.PaymentInterface
                            where p.PaymentType == PaymentType && p.CompanyName == paymentInfo.CompanyName && p.SecretKey == paymentInfo.SecretKey
                            select p;
                    foreach (var p in q)
                    {
                        p.Balance = paymentInfo.Balance;
                    }

                    rows = db.SaveChanges();

                    if (rows > 0)
                    {
                        InsertLog(OrderNo.ToString(), "同步第三方余额" + PaymentTypeName + "成功", paymentInfo, LogRecordLogType.UpdateBalance.GetHashCode(),
                            (sbyte)LogLevel.Success.GetHashCode(), JsonConvert.SerializeObject(q));
                    }
                    //else
                    //{
                    //    InsertLog(OrderNo.ToString(), "同步第三方余额" + PaymentTypeName + "失败", paymentInfo, LogRecordLogType.UpdateBalance.GetHashCode(),
                    //        (sbyte)LogLevel.Error.GetHashCode(), JsonConvert.SerializeObject(q));
                    //}
                }
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog("同步第三方余额" + PaymentTypeName + "发生异常:" + ex.ToString());
            }

            return rows;
        }

        //插入日志数据
        public void InsertLog(string orderNo, string msg, object obj, int type, sbyte level, string affectData = "")
        {
            LogRecord record = new LogRecord();
            record.LogType = type;
            record.LogLevel = level;
            record.CreateDate = DateTime.Now;
            record.CreateName = "秒付宝接口";
            record.LogRemark = msg;
            record.CreateUid = 1;
            record.CompanyId = 2;
            record.RequestUrl = RequestUrl;
            record.AffectData = affectData;
            if (obj != null)
            {
                record.RequestData = JsonConvert.SerializeObject(obj);
            }
            record.OrderNo = Convert.ToInt64(orderNo);

            AddLog(record);
        }

        //写日志到数据库
        public void AddLog(LogRecord record)
        {
            try
            {
                using (var db = new FlashPayContext())
                {
                    db.LogRecord.Add(record);
                    db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog("写日志数据:" + JsonConvert.SerializeObject(record));
                StringHelper.WriteLog("写日志错误:" + ex.ToString());
            }
        }

        //修改费用、馀额、出款卡卡号
        public int UpdatePaymentBankCard(PaymentRecord record)
        {
            int rows = 0;
            try
            {
                string bankStr = string.Empty;
                using (var db = new FlashPayContext())
                {
                    var bankIModel = db.BankCard.Where(e => e.CardType == 3 && e.PaymentType == PaymentType && e.CardName == PaymentTypeName.Replace("(","").Replace(")",""))
                        .Select(e => new
                        {
                            e.Bcid,
                            e.OrderNo,
                            e.CardName,
                            e.CardNumber,
                            e.CardType,
                            e.PaymentType,
                            e.PayFeeRatio,
                            e.CompanyId
                        }).FirstOrDefault();

                    var feeTotal = new decimal(0);
                    int? bcid = null;
                    if (bankIModel != null)
                    {
                        bcid = bankIModel.Bcid;
                        feeTotal = bankIModel.PayFeeRatio * record.WithdrawalAmount;//参数
                        bankStr = JsonConvert.SerializeObject(bankIModel);
                    }

                    // 如果总费用还是 0（银行卡费率为 0 的原因），此时必须还要检查该公司的费率。
                    if (feeTotal == 0)
                    {
                        var company = db.Company.FirstOrDefault(e => e.CompanyId == bankIModel.CompanyId);
                        if (company != null)
                        {
                            feeTotal = company.PayRate * record.WithdrawalAmount;
                        }
                    }

                    var paymentRecord = db.PaymentRecord.Where(e => e.WithdrawalOrderNo == record.WithdrawalOrderNo && e.CompanyId == record.CompanyId).FirstOrDefault();

                    #region 处理上个月的订单还没处理完的问题
                    bool isPrev = false;
                    var month = DateTime.Now.AddMonths(-1).ToString("MM");
                    var tableName = $"PaymentRecord_{month}";
                    if (paymentRecord == null)
                    {
                        //var sql = $"SELECT * FROM {tableName} WHERE OrderNo={record.OrderNo}";
                        var sql = $"SELECT * FROM {tableName} WHERE WithdrawalOrderNo='{record.WithdrawalOrderNo}' && CompanyId={record.CompanyId}";
                        paymentRecord = db.PaymentRecord.FromSql(sql).AsNoTracking().SingleOrDefault();
                        isPrev = true;
                    }
                    #endregion

                    if (paymentRecord != null)
                    {
                        paymentRecord.FeeTotal = feeTotal;//付款费用
                        paymentRecord.CardNumber = bankIModel.CardNumber;
                        paymentRecord.PaymentCardId = bankIModel.Bcid;
                        paymentRecord.WithdrawalFee = PaymentFee;

                        if (isPrev)
                        {
                            var sql = $"update {tableName} set FeeTotal={feeTotal},CardNumber='{bankIModel.CardNumber}',PaymentCardId={bankIModel.Bcid},WithdrawalFee={PaymentFee} where WithdrawalOrderNo='{paymentRecord.WithdrawalOrderNo}' && CompanyId={record.CompanyId}";
                            rows = db.Database.ExecuteSqlCommand(sql);
                        }
                        else
                        {
                            rows = db.SaveChanges();
                        }

                    }
                }
                if (rows > 0)
                {
                    InsertLog(record.OrderNo.ToString(), PaymentTypeName + "给予一组假的银行卡,修改费率成功", record, LogRecordLogType.UpdatePayFee.GetHashCode(),
                        (sbyte)LogLevel.Success.GetHashCode(), bankStr);
                }
                else
                {
                    InsertLog(record.OrderNo.ToString(), PaymentTypeName + "给予一组假的银行卡,修改费率失败", record, LogRecordLogType.UpdatePayFee.GetHashCode(),
                        (sbyte)LogLevel.Error.GetHashCode(), bankStr);
                }
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog("更新费率" + PaymentTypeName + "发生异常:" + ex.ToString());
            }
            return rows;
        }

    }
}

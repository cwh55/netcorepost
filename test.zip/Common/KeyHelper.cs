﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace LinkPayment.Common
{
    public static class KeyHelper
    {
        //构建源字符串(编码、拼接)
        public static string GetParameterStr(IDictionary<string, string> parameters)
        {
            StringBuilder buffer = new StringBuilder();
            int i = 0;
            foreach (string key in parameters.Keys)
            {
                if (i > 0)
                {
                    buffer.AppendFormat("&{0}={1}", key, parameters[key]);
                }
                else
                {
                    buffer.AppendFormat("{0}={1}", key, parameters[key]);
                }
                i++;
            }
           return buffer.ToString();
        }

        //签名
        public static string GetSHA1Sign(string content, Encoding encode)
        {
            try
            {
                SHA1 sha1 = new SHA1CryptoServiceProvider();

                byte[] bytes_in = encode.GetBytes(content);

                byte[] bytes_out = sha1.ComputeHash(bytes_in);

                sha1.Dispose();

                string result = BitConverter.ToString(bytes_out);
                return result.ToUpper().Replace("-","");
            }
            catch (Exception ex)
            {
                throw new Exception("SHA1加密出错：" + ex.Message);
            }
        }
    }
}

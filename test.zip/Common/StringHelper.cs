﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LinkPayment.Common
{
    public static class StringHelper
    {
        #region 将字符串使用base64算法加密 
        /// <summary> 
        /// </param> 
        /// <param name="code">待加密的字符串</param> 
        /// <returns>加密后的字符串</returns> 
        public static string EncodeBase64(string code)
        {
            string encode = "";
            byte[] bytes = Encoding.GetEncoding("UTF-8").GetBytes(code); //将一组字符编码为一个字节序列. 
            try
            {
                encode = Convert.ToBase64String(bytes); //将8位无符号整数数组的子集转换为其等效的,以64为基的数字编码的字符串形式. 
            }
            catch
            {
                encode = code;
            }
            return encode;
        }

        /// <summary> 
        /// 将字符串使用base64算法解密 
        /// </summary> 
        /// <param name="code_type">编码类型</param> 
        /// <param name="code">已用base64算法加密的字符串</param> 
        /// <returns>解密后的字符串</returns> 
        public static string DecodeBase64(string code)
        {
            string decode = "";
            byte[] bytes = Convert.FromBase64String(code); //将2进制编码转换为8位无符号整数数组. 
            try
            {
                decode = Encoding.GetEncoding("UTF-8").GetString(bytes); //将指定字节数组中的一个字节序列解码为一个字符串。 
            }
            catch
            {
                decode = code;
            }
            return decode;
        }
        #endregion

        /// <summary>
        /// HMAC-SHA1加密算法
        /// </summary>
        /// <param name="secret">密钥</param>
        /// <param name="strOrgData">源文</param>
        /// <returns></returns>
        public static string HmacSha1Sign(string secret, string strOrgData)
        {
            var hmacsha1 = new HMACSHA1(Encoding.UTF8.GetBytes(secret));
            var dataBuffer = Encoding.UTF8.GetBytes(strOrgData);
            var hashBytes = hmacsha1.ComputeHash(dataBuffer);
            return Convert.ToBase64String(hashBytes);
        }

        //构建源字符串(编码、拼接)
        public static string GetParameterStr(IDictionary<string, string> parameters, string requestUrl)
        {
            StringBuilder buffer = new StringBuilder();
            int i = 0;
            foreach (string key in parameters.Keys)
            {
                if (i > 0)
                {
                    buffer.AppendFormat("&{0}={1}", key, parameters[key]);
                }
                else
                {
                    buffer.AppendFormat("{0}={1}", key, parameters[key]);
                }
                i++;
            }

            string htmlStr = buffer.ToString();
            string str = Uri.EscapeDataString(htmlStr);
            string serviceAddress = Uri.EscapeDataString(requestUrl);
            string newStr = "POST&" + serviceAddress + "&" + str;
            return newStr;
        }

        //获取HMAC-SHA1加密、Base64编码后的签名字符串
        public static string GetSign(string secretKey, string str)
        {
            str = HmacSha1Sign(secretKey, str);
            return str;
        }

        //获取去掉Host后的网址
        public static string GetHostUrl(string url)
        {
            if (string.IsNullOrEmpty(url)) return "";

            url = url.Replace("http://", "").Replace("https://", "");
            int index = url.IndexOf("/");

            string urlNew = url.Substring(index);
            return urlNew;
        }

        //按天写日志
        public static void WriteLog(string msg)
        {
            try
            {
                string filePath = AppDomain.CurrentDomain.BaseDirectory + "Log";
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                string logPath = AppDomain.CurrentDomain.BaseDirectory + "Log/" + DateTime.Now.ToString("yyyyMMdd") + "_LinkPayment" + ".txt";
                using (StreamWriter sw = File.AppendText(logPath))
                {
                    sw.WriteLine("时间：" + DateTime.Now.ToString("yyy-MM-dd HH:mm:ss"));
                    sw.WriteLine(msg);
                    sw.WriteLine(Environment.NewLine);
                    sw.Flush();
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("日志写入失败:"+ex.ToString());
            }
        }

        //删除一个月以前的日志
        public static void DeleteLog()
        {
            string filePath = AppDomain.CurrentDomain.BaseDirectory + "Log";
            if (Directory.Exists(filePath))
            {
                DirectoryInfo folder = new DirectoryInfo(filePath);
                FileInfo[] fileList = folder.GetFiles();
                if (fileList.Length < 30) return;//不够30条不执行操作
                var delCount = 0;
                foreach (FileInfo file in fileList)
                {
                    string fName = file.Name.Substring(0, file.Name.IndexOf("_"));
                    DateTime dtime = DateTime.ParseExact(fName, "yyyyMMdd", null);
                    TimeSpan ts = DateTime.Now - dtime;
                    if (ts.Days > 30)
                    {
                        file.Delete();
                        delCount++;
                    }
                }
                WriteLog("删除日志文件:" + delCount + "个。");
            }
        }

        public static string SetMd5Str(string str)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(str); //将字符串解析成字节数组，随便按照哪种解析格式都行
            MD5 md5 = MD5.Create();  //使用MD5这个抽象类的Creat()方法创建一个虚拟的MD5类的对象。
            byte[] bufferNew = md5.ComputeHash(buffer); //使用MD5实例的ComputerHash()方法处理字节数组。
            string strNew = null;
            for (int i = 0; i < bufferNew.Length; i++)
            {
                strNew += bufferNew[i].ToString("x2");  //对bufferNew字节数组中的每个元素进行十六进制转换然后拼接成strNew字符串
            }
            return strNew;
        }

    }
}

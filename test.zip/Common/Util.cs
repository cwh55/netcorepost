﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;

namespace LinkPayment.Common
{
   public class Util
    {
        public static Dictionary<string, string> FormToDictionary<T>(T obj)
        {
            var dict = new Dictionary<string, string>();
            Type type = obj.GetType();
            PropertyInfo[] propertyInfos = type.GetProperties();

            foreach (PropertyInfo item in propertyInfos)
            {
                dict.Add(item.Name, (item.GetValue(obj, null) == null ? "" : item.GetValue(obj, null)).ToString());
            }

            return dict.OrderBy(p => p.Key).ToList().ToDictionary(p => p.Key, o => o.Value);
        }

        public static String DictToQueryStr(IDictionary<string, string> obj, Encoding encoding = null)
        {
            if (encoding == null) encoding = Encoding.UTF8;
            return string.Join("&", obj.Select(x => Util.UrlEncode(x.Key, encoding) + "=" + Util.UrlEncode(x.Value, encoding)).ToArray());
        }

        static public string UrlEncode(string temp, Encoding encoding)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < temp.Length; i++)
            {
                string t = temp[i].ToString();
                string k;
                switch (t)
                {
                    case "'":
                        t = "%27";
                        builder.Append(t);
                        break;

                    case " ":
                        t = "%20";
                        builder.Append(t);
                        break;

                    case "(":
                        t = "%28";
                        builder.Append(t);
                        break;

                    case ")":
                        t = "%29";
                        builder.Append(t);
                        break;

                    case "!":
                        t = "%21";
                        builder.Append(t);
                        break;

                    case "*":
                        t = "%2A";
                        builder.Append(t);
                        break;

                    default:
                        k = HttpUtility.UrlEncode(t, encoding);
                        if (t == k)
                        {
                            builder.Append(t);
                        }
                        else
                        {
                            builder.Append(k.ToUpper());
                        }
                        break;
                }
            }
            return builder.ToString();
        }
    }
}

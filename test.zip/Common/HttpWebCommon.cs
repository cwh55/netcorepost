﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;

namespace LinkPayment.Common
{
    public static class HttpWebCommon
    {
        //请求Http接口(不加签名)
        public static string GetResult(string serviceAddress, string strContent)
        {
            string baseRequest = JsonConvert.SerializeObject(strContent);

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(serviceAddress);
            request.Method = "POST";
            request.ContentType = "application/json";
            Encoding requestEncoding = Encoding.GetEncoding("UTF-8");

            byte[] data = requestEncoding.GetBytes(baseRequest);
            request.ContentLength = data.Length;
            using (Stream stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
                stream.Close();
            }

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream(), requestEncoding);
            string retString = reader.ReadToEnd();
            return retString;
        }

        //Get请求接口
        public static string GetDataByUrl(string getBankUrl)
        {
            var request = (HttpWebRequest)WebRequest.Create(getBankUrl);
            var response = (HttpWebResponse)request.GetResponse();
            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
            return responseString;
        }


        //Get请求(更新付款成功后，需要进行第零到第一次的推送，需要调用本地接口)
        public static string PushRequest(string getUrl, string info)
        {
            string resultInfo = string.Empty;
            try
            {
                System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
                var ans = client.GetStringAsync(getUrl);
                resultInfo = ans.Result;
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog(info + ":" + ex.Message);
            }
            return resultInfo;
        }

        //Post请求
        public static string Post(string testStr, string postUrl)
        {
            HttpContent postContent = new StringContent(testStr);
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postUrl);//调取接口地址
            var result = client.PostAsync(postUrl, postContent);
            var ans = result.Result.Content.ReadAsStringAsync();
            string resultInfo = ans.Result;
            return resultInfo;
        }

        //Post请求
        public static string Post(IDictionary<string, string> testStr, string postUrl)
        {
            var postContent = new FormUrlEncodedContent(testStr);
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postUrl);//调取接口地址
            var result = client.PostAsync(postUrl, postContent);
            var ans = result.Result.Content.ReadAsStringAsync();
            string resultInfo = ans.Result;
            return resultInfo;
        }

    }
}

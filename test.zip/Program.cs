﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LinkPayment.Common;
using LinkPayment.Model;
using static LinkPayment.Model.GlobalEnum;

namespace LinkPayment
{
    class Program
    {
        #region 全局变量
        private static string httpUrl = "https://atm.xlinkpay.com/gateway/dfm.html";
        private static string searchPayUrl = "https://atm.xlinkpay.com/gateway/df_query.html";
        private static string searchBalanceUrl = "https://atm.xlinkpay.com/gateway/queryMoney.html";
        private static string paymentType = "10";//LinkPay

        private static Dictionary<string, string> bankList = GetBankList();

        private static IServiceProvider serviceProvider = new ServiceCollection()
                    .AddTransient<StoredProcedureService, StoredProcedure>()
                    .BuildServiceProvider();

        private static StoredProcedureService counter = serviceProvider.GetService<StoredProcedureService>();
        #endregion

        static void Main(string[] args)
        {
            FirstPaymentRecord();
            SecondPaymentRecord();
        }

        #region 主要业务
        //将未付款的订单设为付款中
        public static void FirstPaymentRecord()
        {
            var q = CommonPaymentRecord(1);

            if (q != null && q.Count() > 0)
            {
                var count = q.Count();
                for (int i = 0; i < count; i++)
                {
                    PaymentInterface payment = GetPaymentInterface(q[i].CompanyId);
                    if (payment != null)
                    {
                        #region 金额验证
                        if (q[i].WithdrawalAmount < 10)
                        {
                            StringHelper.WriteLog("订单ID:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",最低提现为10元。");
                            continue;
                        }
                        if (i == 0)
                        {
                            //同步余额到各公司(之所以写在这里是为了保证测试环境与正式环境数据一致)
                            PaymentBanlance pBanlance = GetBalanceModel(payment.CompanyName, q[i]);
                            JObject jBanlance = CommonCashRedesign(pBanlance, payment.SecretKey, 2);//类型为2
                            if (jBanlance["status"].ToString() == "1")//is_success=true
                            {
                                var balance = Convert.ToDecimal(jBanlance["money"]);
                                payment.Balance = balance;
                                counter.UpdatePaymentInterfaceBalance(q[i].OrderNo, payment);
                            }
                        }
                        if (payment.Balance < q[i].WithdrawalAmount + 2)
                        {
                            StringHelper.WriteLog("订单ID:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",商户余额不足。");
                            continue;
                        }
                        #endregion
 
                        PaymentEntity payOrder = GetPaymentModel(payment.CompanyName, q[i]);
                        JObject jo = CommonCashRedesign(payOrder, payment.SecretKey);

                        string fxcode = jo["error_msg"].ToString();//错误信息
                        #region 代付成功
                        if (jo["is_success"].ToString().ToLower() == "true")
                        {
                            //订单处理结果【0未处理】【1银行处理中】【2已打款】【3失败】
                            string status = jo["trade_status"].ToString();
                            if (!status.Equals(OrderStatus.已打款))
                            {
                                string trade_no= jo["trade_no"].ToString();
                                sbyte pStatus = 4;
                                string tip = "订单: " + q[i].WithdrawalOrderNo.Replace("_", "") + ",状态已设置为(处理中),原因: " + fxcode;
                                counter.UpdatePaymentRecord(new PaymentRecord
                                {
                                    OrderNo = q[i].OrderNo,
                                    WithdrawalOrderNo = q[i].WithdrawalOrderNo,
                                    CompanyId = q[i].CompanyId,//改用这两个条件修改订单信息
                                    PaymentStatus = pStatus,
                                    BankSerialNo= trade_no,
                                    PaymentFailInfo = fxcode
                                });
                                StringHelper.WriteLog(tip);
                                Tip(fxcode);
                            }
                            else
                            {
                                StringHelper.WriteLog("订单:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",状态为已打款,原因:" + fxcode);
                            }
                        }
                        else
                        {
                            counter.UpdatePaymentRecord(new PaymentRecord
                            {
                                OrderNo = q[i].OrderNo,
                                WithdrawalOrderNo = q[i].WithdrawalOrderNo,
                                CompanyId = q[i].CompanyId,
                                PaymentStatus = 4,
                                PaymentFailInfo = fxcode
                            });
                            StringHelper.WriteLog("订单:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",代付申请失败(状态将改为[付款中]),原因:" + fxcode);
                        }

                        #endregion
                    }
                    else
                    {
                        StringHelper.WriteLog("第三方接口信息为空");
                        Tip("第三方接口信息为空");
                        continue;
                    }
                }
            }
            else
            {
                StringHelper.WriteLog("未付款的记录为空");
                Tip("未付款的记录为空!");
            }
        }

        //根据付款类型查询付款记录
        public static List<PaymentRecord> CommonPaymentRecord(int pType)
        {
            try
            {
                IConfigurationRoot configBuilder = new ConfigurationBuilder().AddJsonFile("AppSetting.json").Build();
                httpUrl = configBuilder["ConnectionStrings:HttpUrl"] == null ? httpUrl : configBuilder["ConnectionStrings:HttpUrl"];
                searchPayUrl = configBuilder["ConnectionStrings:SearchPayUrl"] == null ? searchPayUrl : configBuilder["ConnectionStrings:SearchPayUrl"];
                searchBalanceUrl = configBuilder["ConnectionStrings:SearchBalanceUrl"] == null ? searchBalanceUrl : configBuilder["ConnectionStrings:SearchBalanceUrl"];
                paymentType = configBuilder["ConnectionStrings:PaymentType"] == null ? paymentType : configBuilder["ConnectionStrings:PaymentType"];
            }
            catch (Exception)
            {
                Common.StringHelper.WriteLog("数据库配置文件AppSetting.json不存在");
                Tip("数据库配置文件AppSetting.json不存在", true);
            }

            //DateTime start = Convert.ToDateTime("2019-06-01 00:00:01");
            DateTime start = Convert.ToDateTime(DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd 00:00:01"));
            DateTime end = DateTime.Now;

            try
            {
                //获取付款记录(付款中、LinkPay)
                var recordlist = counter.SelectPaymentRecordNew(start, end, Convert.ToInt32(paymentType), pType);
                var q = recordlist.ToList();
                return q;
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog("系统错误:" + ex.ToString());
                Tip("系统错误" + ex.Message, true);
            }
            return null;
        }

        //获取第三方接口信息
        public static PaymentInterface GetPaymentInterface(int companyId)
        {
            PaymentInterface payment = counter.GetPaymentInfo(new PaymentInterface
            {
                CompanyId = companyId,
                PaymentType = Convert.ToSByte(paymentType),
                EnableBalanceCheck = 1  //启用余额检查
            });
            return payment;
        }

        //处理付款中的数据
        public static void SecondPaymentRecord()
        {
            var q = CommonPaymentRecord(4);
            if (q != null && q.Count() > 0)
            {
                var count = q.Count();
                for (int i = 0; i < count; i++)
                {
                    PaymentInterface payment = GetPaymentInterface(q[i].CompanyId);
                    if (payment != null)
                    {
                        if (q[i].WithdrawalAmount < 10)
                        {
                            StringHelper.WriteLog("订单ID:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",最低提现为10元。");
                            continue;
                        }
                        if (payment.Balance < q[i].WithdrawalAmount + 2)
                        {
                            StringHelper.WriteLog("订单ID:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",商户余额不足。");
                            continue;
                        }

                        #region 调取代付查询接口之后的处理
                        PaymentOrder payOrder = GetOrderModel(payment.CompanyName, q[i]);
                        JObject jo = CommonCashRedesign(payOrder, payment.SecretKey, 1);
                        if (jo["is_success"].ToString().ToLower() == "true") //成功
                        {
                            //【0未处理】【1银行处理中】【2已打款】【3失败】
                            string status = jo["trade_status"].ToString(); 

                            int paymentStatus = Convert.ToInt32(status);
                            //还处于未处理(付款中)的订单,暂时不做任何操作,等待下一轮循环处理
                            if (paymentStatus <=1)
                            {
                                StringHelper.WriteLog("订单ID:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",目前还处于未处理(付款中)状态,请稍后......");
                                continue;
                            }

                            string trade_no = jo["trade_no"].ToString();

                            //根据q[i].OrderNo 修改订单状态、交易时间等;然后修改余额(PaymentInterface.Balance)
                            string rInfo = counter.UpdatePaymentInterfaceBalance(
                                          new PaymentRecord
                                          {
                                              OrderNo = q[i].OrderNo,
                                              WithdrawalOrderNo = q[i].WithdrawalOrderNo,
                                              CompanyId = q[i].CompanyId,//改用这两个条件修改订单信息
                                              PaymentStatus = Convert.ToSByte(paymentStatus),
                                              BankSerialNo= trade_no
                                          },
                                          new PaymentInterface
                                          {
                                              PaymentInterfaceID = payment.PaymentInterfaceID,
                                              Balance = q[i].WithdrawalAmount + 2
                                          });
                            StringHelper.WriteLog(rInfo);
                            Console.WriteLine(rInfo);

                            if (rInfo == "修改第三方余额成功" && status == OrderStatus.已打款.GetHashCode().ToString()) 
                            {
                                string pushUrl = "http://127.0.0.1:7120/api/Compat/V1/Push/AddWithdrawalPushRequest?orderNo=" + q[i].OrderNo;
                                string info = HttpWebCommon.PushRequest(pushUrl, "调用本地接口进行第一次推送失败");//推送
                                StringHelper.WriteLog("零到第一次的推送结果:" + info);
                                StringHelper.WriteLog("订单:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",开始同步余额....");

                                //同步余额到各公司
                                PaymentBanlance pOrder2 = GetBalanceModel(payment.CompanyName, q[i]);
                                JObject jo2 = CommonCashRedesign(pOrder2, payment.SecretKey, 2);//类型为2
                                if (jo2["status"].ToString() == "1")
                                {
                                    var balance = Convert.ToDecimal(jo2["money"]);
                                    payment.Balance = balance;
                                    counter.UpdatePaymentInterfaceBalance(q[i].OrderNo, payment);
                                }
                            }
                            StringHelper.WriteLog("订单:" + q[i].WithdrawalOrderNo.Replace("_", "") + ",流程结束！！");
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(q[i].PaymentFailInfo) && jo["error_msg"]!=null)
                            {
                                counter.UpdatePaymentRecord(new PaymentRecord
                                {
                                    OrderNo = q[i].OrderNo,
                                    WithdrawalOrderNo = q[i].WithdrawalOrderNo,
                                    CompanyId = q[i].CompanyId,
                                    PaymentStatus = q[i].PaymentStatus,
                                    PaymentFailInfo = jo["error_msg"].ToString(),
                                });
                                Console.WriteLine(jo["error_msg"].ToString());//查询状态失败
                            }
                        }
                        #endregion
                    }
                    else
                    {
                        StringHelper.WriteLog("公司ID:" + q[i].CompanyId + ",第三方接口信息为空");
                        Tip("公司ID:" + q[i].CompanyId + ",第三方接口信息为空");
                        continue;
                    }
                }

                StringHelper.DeleteLog();//删除30天以前的日志文件
            }
            else
            {
                StringHelper.WriteLog("付款中的记录为空");
                Tip("付款中的记录为空");
            }
        }

        #endregion

        #region 代付、订单查询、余额查询Model
        //代付——余额查询提交参数实体
        public static PaymentBanlance GetBalanceModel(string fxNo, PaymentRecord qi)
        {
            PaymentBanlance pOrder = new PaymentBanlance();
            pOrder.version = "1.0";
            pOrder.input_charset = "utf-8";
            pOrder.merchant_code = fxNo;//商户号
            pOrder.request_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            pOrder.order_no = qi.WithdrawalOrderNo.Replace("_", "");
            return pOrder;
        }

        //代付——提交参数实体
        public static PaymentEntity GetPaymentModel(string fxNo, PaymentRecord qi)
        {
            PaymentEntity tfe = new PaymentEntity();
            tfe.version = "1.0";
            tfe.input_charset = "utf-8";
            tfe.merchant_code = fxNo;//商户号
            tfe.amount = qi.WithdrawalAmount.ToString("#0.00");
            tfe.order_no = qi.WithdrawalOrderNo.Replace("_", "");
            tfe.batch_no = qi.OrderNo;//批次号
            tfe.request_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); //代付时间
            tfe.bank_code = GetBankCode(qi.WithdrawalBankName, qi.WithdrawalCardBankFlag, bankList);//银行编码
            tfe.account_name = qi.WithdrawalAccountName;
            tfe.account_number = qi.WithdrawalCardNumber;//收款卡号
            tfe.remark = "LinkPay";//备注
            tfe.notify_url = "http://172.16.35.154:8008/api/FxNotify/Callback";
            return tfe;
        }

        //代付——订单查询提交参数实体
        public static PaymentOrder GetOrderModel(string fxNo, PaymentRecord qi)
        {
            PaymentOrder pOrder = new PaymentOrder();
            pOrder.version = "1.0";
            pOrder.input_charset = "utf-8";
            pOrder.merchant_code = fxNo;//商户号
            pOrder.request_time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            pOrder.order_no = qi.WithdrawalOrderNo.Replace("_", "");
            return pOrder;
        }
        #endregion

        #region 代付提交
        //获得Post请求接口返回信息
        public static string GetResult(IDictionary<string, string> parameters, string keyStr, string info, string url)
        {
            string baseRequest = string.Empty;
            string orderNo = string.Empty;

            if (info == "<订单查询>")
            {
                orderNo=parameters["order_no"];
            }
            else if (info == "<余额查询>")
            {
                orderNo = parameters["order_no"];
                parameters.Remove("order_no");
            }
            else
            {
                orderNo=parameters["order_no"];
            }

            baseRequest = KeyHelper.GetParameterStr(parameters);
            baseRequest += "&key=" + keyStr;
            StringHelper.WriteLog("订单号:" + orderNo + "," + info + "接口拼接签名字符串为:" + baseRequest);

            //签名
            string signStr = StringHelper.SetMd5Str(baseRequest);
            StringHelper.WriteLog("订单号:" + orderNo + "," + info + "接口Md5算法生成签名值为:" + signStr);

            string resultInfo = string.Empty;
            try
            {
                IDictionary<string, string> baseContent = parameters;//参数
                baseContent.Add("sign", signStr);//加上签名作为新的参数.ToUpper()

                StringHelper.WriteLog("订单号:" + orderNo + "," + info + "接口(推送)参数为:" + JsonConvert.SerializeObject(baseContent));

                resultInfo = HttpWebCommon.Post(baseContent, url);
                StringHelper.WriteLog("订单号:" + orderNo + "," + info + "接口(回调)——返回信息:" + resultInfo);
            }
            catch (Exception ex)
            {
                StringHelper.WriteLog("订单号:" + orderNo + "," + info + "接口(异常)——:" + ex.ToString());
            }

            return resultInfo;
        }

        //代付——调用Post请求
        public static JObject CommonCashRedesign<T>(T obj, string SecretKey, int type = 0)
        {
            //设置参数(排序)
            IDictionary<string, string> parameters = Util.FormToDictionary(obj);
            string info = "<代付申请>";
            string url = httpUrl;
            if (type == 1)
            {
                info = "<订单查询>";
                url = searchPayUrl;
            }
            else if (type == 2)
            {
                info = "<余额查询>";
                url = searchBalanceUrl;
            }
            string returnInfo = GetResult(parameters, SecretKey, info,url);//代付提交接口
            JObject jo = (JObject)JsonConvert.DeserializeObject(returnInfo);
            return jo;
        }
        #endregion

        #region 公共方法
        //银行列表
        public static Dictionary<string, string> GetBankList()
        {
            Dictionary<string, string> bList = new Dictionary<string, string>();
            bList.Add("ABC", "农业银行"); bList.Add("BOC", "中国银行");
            bList.Add("BCCB", "北京银行"); bList.Add("BJRCB", "北京农商银行");
            bList.Add("BOS", "上海银行"); bList.Add("CBHB", "渤海银行");
            bList.Add("CCB", "建设银行"); bList.Add("CEB", "光大银行");
            bList.Add("COMM", "交通银行"); bList.Add("CSCB", "长沙银行");

            bList.Add("GDB", "广东发展银行"); bList.Add("SNXS", "深圳农商行"); 
            bList.Add("PSBC", "中国邮储银行"); bList.Add("HNNXS", "湖南农信社");
            bList.Add("CZB", "浙商银行"); bList.Add("GUILINBANK", "桂林银行");
            bList.Add("NCCB", "江西银行"); bList.Add("LIUZHOUBANK", "柳州银行");
            bList.Add("HRXJ", "华融湘江银行"); bList.Add("RCC", "农村信用社");

            bList.Add("SHRCB", "上海农村商业银行"); bList.Add("CZCB", "浙江稠州商业银行");
            bList.Add("HCCB", "杭州银行"); bList.Add("SDB", "深圳发展银行");
            bList.Add("HXB", "华夏银行"); bList.Add("NJCB", "南京银行");
            bList.Add("ICBC", "工商银行"); bList.Add("CITIC", "中信银行");
            bList.Add("CMB", "招商银行"); bList.Add("CMBC", "民生银行");
            bList.Add("SPDB", "浦发银行"); bList.Add("NBCB", "宁波银行");
            bList.Add("SZPAB", "平安银行"); bList.Add("CIB", "兴业银行"); 
            return bList;
        }

        //获取正确的银行名称
        public static string GetBankCode(string bankName, string bankCode, Dictionary<string, string> bankList)
        {
            if (string.IsNullOrEmpty(bankName)) return bankCode;
            if (bankList == null || bankList.Count == 0) return bankName;

            switch (bankName)
            {
                case "广发银行":
                    return "GDB";
                case "邮政储蓄银行":
                    return "PSBC";
                case "深圳农村商业银行":
                    return "SNXS";
            }
            var item = bankList.Where(e => e.Value.Contains(bankName)).FirstOrDefault();
            if (item.Key == null) return bankName;
            return item.Key;
        }

        //输出
        public static void Tip(string str, bool isExit = false)
        {
            Console.WriteLine(str);
            if (isExit) Console.ReadLine();
        }
        #endregion

    }
}
